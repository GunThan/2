## Pingger Stable For Game
Pingger Stable is used to fix unstable pings when playing games and there are additional features, you install one module with multi function
## Credit
- [topjohnwu  : Magisk](https://github.com/topjohnwu/Magisk)
- [gloeyisk   : Universal GMS Dose](https://forum.xda-developers.com/apps/magisk/module-universal-gms-doze-t3853710/amp/)
- [simonsmh   : Wifi Bonding](https://forum.xda-developers.com/apps/magisk/module-wifi-bonding-t3735919/amp/)
## Supports
- [Youtube](https://www.youtube.com./c/wahyu6070)
- [GitHub](https://github.com/wahyu6070)
- [Xda](https://forum.xda-developers.com/android/software/magisk-module-pingger-stable-game-t4041289)
- [Telegram group](https://t.me/wahyu6070group)
